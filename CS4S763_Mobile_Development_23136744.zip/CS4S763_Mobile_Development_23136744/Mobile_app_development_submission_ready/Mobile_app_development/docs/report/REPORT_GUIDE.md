# Assignment Report Guide

Use this project to write a short report with these headings:

## 1. Justification of theme choice
I selected a **Book Collection API** because it provides clearly categorized data through books, authors, and genres. This makes it suitable for demonstrating CRUD operations and relational database design in a simple and understandable way.

## 2. Libraries used
- Spring Boot
- Spring Web
- Spring Data JPA
- Spring Security
- Spring Validation
- H2 Database
- JJWT
- JUnit 5
- MockMvc

## 3. Source of database contents
The database records in this project were manually created for demonstration purposes using seeded sample data.

## 4. Overview of API endpoints
- `POST /api/auth/login` - authenticate user and return JWT token
- `GET /api/books` - retrieve all books
- `GET /api/books/{id}` - retrieve one book by ID
- `POST /api/books` - create a new book
- `PUT /api/books/{id}` - update an existing book
- `DELETE /api/books/{id}` - delete a book
- similar CRUD endpoints are available for authors and genres

## 5. Overview of tests
The project includes automated tests for:
- successful login
- authenticated retrieval of books
- authenticated creation of books
- service-layer creation and retrieval of a book

## 6. Link to repository
Add your GitHub repository link here after uploading the project.
