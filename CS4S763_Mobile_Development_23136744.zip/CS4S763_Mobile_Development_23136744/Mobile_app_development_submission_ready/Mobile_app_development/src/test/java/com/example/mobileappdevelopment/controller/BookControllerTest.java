package com.example.mobileappdevelopment.controller;

import com.example.mobileappdevelopment.dto.BookRequest;
import com.example.mobileappdevelopment.dto.LoginRequest;
import com.example.mobileappdevelopment.entity.Author;
import com.example.mobileappdevelopment.entity.Book;
import com.example.mobileappdevelopment.entity.Genre;
import com.example.mobileappdevelopment.entity.User;
import com.example.mobileappdevelopment.repository.AuthorRepository;
import com.example.mobileappdevelopment.repository.BookRepository;
import com.example.mobileappdevelopment.repository.GenreRepository;
import com.example.mobileappdevelopment.repository.UserRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc
@ActiveProfiles("test")
class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    private GenreRepository genreRepository;

    @Autowired
    private BookRepository bookRepository;

    private Author author;
    private Genre genre;

    @BeforeEach
    void setUp() {
        bookRepository.deleteAll();
        authorRepository.deleteAll();
        genreRepository.deleteAll();
        userRepository.deleteAll();

        userRepository.save(new User("admin", passwordEncoder.encode("password123"), "ROLE_ADMIN"));
        author = authorRepository.save(new Author("George Orwell", "United Kingdom"));
        genre = genreRepository.save(new Genre("Dystopian"));
        bookRepository.save(new Book("1984", "9780451524935", 1949, author, genre));
    }

    @Test
    void shouldGetAllBooksWhenAuthenticated() throws Exception {
        String token = obtainToken();

        mockMvc.perform(get("/api/books")
                        .header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("1984"));
    }

    @Test
    void shouldCreateBookWhenAuthenticated() throws Exception {
        String token = obtainToken();

        BookRequest request = new BookRequest();
        request.setTitle("Animal Farm");
        request.setIsbn("9780451526342");
        request.setPublicationYear(1945);
        request.setAuthorId(author.getId());
        request.setGenreId(genre.getId());

        mockMvc.perform(post("/api/books")
                        .header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Animal Farm"))
                .andExpect(jsonPath("$.authorName").value("George Orwell"));
    }

    private String obtainToken() throws Exception {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setUsername("admin");
        loginRequest.setPassword("password123");

        MvcResult result = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode root = objectMapper.readTree(result.getResponse().getContentAsString());
        return root.get("token").asText();
    }
}