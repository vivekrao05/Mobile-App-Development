package com.example.mobileappdevelopment.service;

import com.example.mobileappdevelopment.dto.BookRequest;
import com.example.mobileappdevelopment.dto.BookResponse;
import com.example.mobileappdevelopment.entity.Author;
import com.example.mobileappdevelopment.entity.Genre;
import com.example.mobileappdevelopment.repository.AuthorRepository;
import com.example.mobileappdevelopment.repository.BookRepository;
import com.example.mobileappdevelopment.repository.GenreRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
@ActiveProfiles("test")
class BookServiceTest {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    private GenreRepository genreRepository;

    private Author author;
    private Genre genre;

    @BeforeEach
    void setUp() {
        bookRepository.deleteAll();
        authorRepository.deleteAll();
        genreRepository.deleteAll();

        author = authorRepository.save(new Author("Dan Brown", "United States"));
        genre = genreRepository.save(new Genre("Thriller"));
    }

    @Test
    void shouldCreateAndFetchBook() {
        BookRequest request = new BookRequest();
        request.setTitle("The Da Vinci Code");
        request.setIsbn("9780307474278");
        request.setPublicationYear(2003);
        request.setAuthorId(author.getId());
        request.setGenreId(genre.getId());

        BookResponse created = bookService.createBook(request);
        BookResponse fetched = bookService.getBookById(created.getId());

        assertEquals("The Da Vinci Code", fetched.getTitle());
        assertEquals("Dan Brown", fetched.getAuthorName());
        assertEquals("Thriller", fetched.getGenreName());
    }
}
