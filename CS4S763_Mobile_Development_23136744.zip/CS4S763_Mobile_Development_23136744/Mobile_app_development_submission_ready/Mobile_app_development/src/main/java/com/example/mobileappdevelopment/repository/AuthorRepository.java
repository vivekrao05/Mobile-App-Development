package com.example.mobileappdevelopment.repository;

import com.example.mobileappdevelopment.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AuthorRepository extends JpaRepository<Author, Long> {
}
