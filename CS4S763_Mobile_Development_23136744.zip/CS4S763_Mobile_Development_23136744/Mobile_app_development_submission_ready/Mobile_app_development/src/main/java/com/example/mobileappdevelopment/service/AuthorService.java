package com.example.mobileappdevelopment.service;

import com.example.mobileappdevelopment.dto.AuthorRequest;
import com.example.mobileappdevelopment.dto.AuthorResponse;
import com.example.mobileappdevelopment.entity.Author;
import com.example.mobileappdevelopment.exception.ResourceNotFoundException;
import com.example.mobileappdevelopment.repository.AuthorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorService(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    public List<AuthorResponse> getAllAuthors() {
        return authorRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public AuthorResponse getAuthorById(Long id) {
        Author author = findAuthorEntity(id);
        return mapToResponse(author);
    }

    public AuthorResponse createAuthor(AuthorRequest request) {
        Author author = new Author(request.getName(), request.getCountry());
        return mapToResponse(authorRepository.save(author));
    }

    public AuthorResponse updateAuthor(Long id, AuthorRequest request) {
        Author author = findAuthorEntity(id);
        author.setName(request.getName());
        author.setCountry(request.getCountry());
        return mapToResponse(authorRepository.save(author));
    }

    public void deleteAuthor(Long id) {
        Author author = findAuthorEntity(id);
        authorRepository.delete(author);
    }

    public Author findAuthorEntity(Long id) {
        return authorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Author not found with id: " + id));
    }

    private AuthorResponse mapToResponse(Author author) {
        return new AuthorResponse(author.getId(), author.getName(), author.getCountry());
    }
}
