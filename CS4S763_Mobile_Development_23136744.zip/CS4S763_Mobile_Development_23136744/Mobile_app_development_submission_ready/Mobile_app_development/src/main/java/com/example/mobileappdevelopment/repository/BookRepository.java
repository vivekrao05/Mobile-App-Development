package com.example.mobileappdevelopment.repository;

import com.example.mobileappdevelopment.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
}
