package com.example.mobileappdevelopment.config;

import com.example.mobileappdevelopment.entity.Author;
import com.example.mobileappdevelopment.entity.Book;
import com.example.mobileappdevelopment.entity.Genre;
import com.example.mobileappdevelopment.entity.User;
import com.example.mobileappdevelopment.repository.AuthorRepository;
import com.example.mobileappdevelopment.repository.BookRepository;
import com.example.mobileappdevelopment.repository.GenreRepository;
import com.example.mobileappdevelopment.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@Profile("!test")
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final AuthorRepository authorRepository;
    private final GenreRepository genreRepository;
    private final BookRepository bookRepository;
    private final PasswordEncoder passwordEncoder;

    public DataInitializer(UserRepository userRepository,
                           AuthorRepository authorRepository,
                           GenreRepository genreRepository,
                           BookRepository bookRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.authorRepository = authorRepository;
        this.genreRepository = genreRepository;
        this.bookRepository = bookRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            userRepository.save(new User("admin", passwordEncoder.encode("password123"), "ROLE_ADMIN"));
            userRepository.save(new User("reviewer", passwordEncoder.encode("review123"), "ROLE_USER"));
        }

        if (authorRepository.count() == 0 && genreRepository.count() == 0 && bookRepository.count() == 0) {
            Author orwell = authorRepository.save(new Author("George Orwell", "United Kingdom"));
            Author rowling = authorRepository.save(new Author("J.K. Rowling", "United Kingdom"));
            Author danBrown = authorRepository.save(new Author("Dan Brown", "United States"));

            Genre dystopian = genreRepository.save(new Genre("Dystopian"));
            Genre fantasy = genreRepository.save(new Genre("Fantasy"));
            Genre thriller = genreRepository.save(new Genre("Thriller"));

            bookRepository.save(new Book("1984", "9780451524935", 1949, orwell, dystopian));
            bookRepository.save(new Book("Harry Potter and the Philosopher's Stone", "9780747532699", 1997, rowling, fantasy));
            bookRepository.save(new Book("The Da Vinci Code", "9780307474278", 2003, danBrown, thriller));
        }
    }
}
