package com.example.mobileappdevelopment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileAppDevelopmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(MobileAppDevelopmentApplication.class, args);
    }
}
