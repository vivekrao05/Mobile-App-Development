package com.example.mobileappdevelopment.service;

import com.example.mobileappdevelopment.dto.BookRequest;
import com.example.mobileappdevelopment.dto.BookResponse;
import com.example.mobileappdevelopment.entity.Author;
import com.example.mobileappdevelopment.entity.Book;
import com.example.mobileappdevelopment.entity.Genre;
import com.example.mobileappdevelopment.exception.ResourceNotFoundException;
import com.example.mobileappdevelopment.repository.BookRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorService authorService;
    private final GenreService genreService;

    public BookService(BookRepository bookRepository, AuthorService authorService, GenreService genreService) {
        this.bookRepository = bookRepository;
        this.authorService = authorService;
        this.genreService = genreService;
    }

    public List<BookResponse> getAllBooks() {
        return bookRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public BookResponse getBookById(Long id) {
        Book book = findBookEntity(id);
        return mapToResponse(book);
    }

    public BookResponse createBook(BookRequest request) {
        Author author = authorService.findAuthorEntity(request.getAuthorId());
        Genre genre = genreService.findGenreEntity(request.getGenreId());

        Book book = new Book();
        book.setTitle(request.getTitle());
        book.setIsbn(request.getIsbn());
        book.setPublicationYear(request.getPublicationYear());
        book.setAuthor(author);
        book.setGenre(genre);

        return mapToResponse(bookRepository.save(book));
    }

    public BookResponse updateBook(Long id, BookRequest request) {
        Book book = findBookEntity(id);
        Author author = authorService.findAuthorEntity(request.getAuthorId());
        Genre genre = genreService.findGenreEntity(request.getGenreId());

        book.setTitle(request.getTitle());
        book.setIsbn(request.getIsbn());
        book.setPublicationYear(request.getPublicationYear());
        book.setAuthor(author);
        book.setGenre(genre);

        return mapToResponse(bookRepository.save(book));
    }

    public void deleteBook(Long id) {
        Book book = findBookEntity(id);
        bookRepository.delete(book);
    }

    public Book findBookEntity(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
    }

    private BookResponse mapToResponse(Book book) {
        return new BookResponse(
                book.getId(),
                book.getTitle(),
                book.getIsbn(),
                book.getPublicationYear(),
                book.getAuthor().getId(),
                book.getAuthor().getName(),
                book.getGenre().getId(),
                book.getGenre().getName()
        );
    }
}
