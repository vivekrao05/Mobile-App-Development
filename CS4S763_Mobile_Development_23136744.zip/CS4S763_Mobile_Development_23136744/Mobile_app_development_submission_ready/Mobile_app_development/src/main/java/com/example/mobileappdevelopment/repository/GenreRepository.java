package com.example.mobileappdevelopment.repository;

import com.example.mobileappdevelopment.entity.Genre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenreRepository extends JpaRepository<Genre, Long> {
}
