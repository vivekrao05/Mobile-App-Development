package com.example.mobileappdevelopment.service;

import com.example.mobileappdevelopment.dto.GenreRequest;
import com.example.mobileappdevelopment.dto.GenreResponse;
import com.example.mobileappdevelopment.entity.Genre;
import com.example.mobileappdevelopment.exception.ResourceNotFoundException;
import com.example.mobileappdevelopment.repository.GenreRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenreService {

    private final GenreRepository genreRepository;

    public GenreService(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }

    public List<GenreResponse> getAllGenres() {
        return genreRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public GenreResponse getGenreById(Long id) {
        Genre genre = findGenreEntity(id);
        return mapToResponse(genre);
    }

    public GenreResponse createGenre(GenreRequest request) {
        Genre genre = new Genre(request.getName());
        return mapToResponse(genreRepository.save(genre));
    }

    public GenreResponse updateGenre(Long id, GenreRequest request) {
        Genre genre = findGenreEntity(id);
        genre.setName(request.getName());
        return mapToResponse(genreRepository.save(genre));
    }

    public void deleteGenre(Long id) {
        Genre genre = findGenreEntity(id);
        genreRepository.delete(genre);
    }

    public Genre findGenreEntity(Long id) {
        return genreRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Genre not found with id: " + id));
    }

    private GenreResponse mapToResponse(Genre genre) {
        return new GenreResponse(genre.getId(), genre.getName());
    }
}
