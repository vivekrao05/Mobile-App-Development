# Book Collection REST API with JWT Authentication

## Overview

This project is a secured RESTful API developed in Java using Spring Boot. The application is based on a **Book Collection** system and allows authorised users to manage books, authors, and genres.

Authentication is implemented using **Spring Security** and **JWT**. A user must first log in using valid credentials, receive a token, and then use that token to access secured endpoints.

This project was created as part of a university coursework assignment to demonstrate CRUD operations, API security, testing, and maintainable project structure.

## Features

- User login with JWT token generation
- Secure access to protected API endpoints
- CRUD operations for books
- Retrieval and creation of authors
- Retrieval and creation of genres
- H2 in-memory database for local development
- Unit and integration tests for core functionality

## Technologies Used

- Java 17
- Spring Boot
- Spring Web
- Spring Data JPA
- Spring Security
- Spring Validation
- H2 Database
- JUnit 5
- MockMvc
- JJWT

## Project Structure

src/main/java/com/example/mobileappdevelopment
- config
- controller
- dto
- entity
- exception
- repository
- security
- service

src/test/java/com/example/mobileappdevelopment
- controller
- service

## Main Entities

- User
- Author
- Genre
- Book

## Authentication

### Login Endpoint
`POST /api/auth/login`

### Default Demo Credentials
- Username: `admin`
- Password: `password123`

